

<div class="brand clearfix" style="background-color: #f47c3c; height:60px">
		<a href="#" class="logo" style="font-size:13px; color:black; text-decoration:none;">Multiplex Management System</a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			<li class="ts-account">
				<a href="#" style="color:black; background-color: #f47c3c; height:60px; text-decoration:none;" ><img src="img\Multiplex8-650x433.jpg"  style="border: 3px solid white; border-radius:90%; height:30px;"> Account <i class="fa fa-angle-down hidden-side m-auto" ></i></a>
				<ul style="background-color: #e7e5e5;">
					<li><a href="admin-profile.php" style="text-decoration:none; background-color: #e7e5e5; color:black;" >My Account</a></li>
					<li><a href="logout.php" style="text-decoration:none; background-color: #e7e5e5; color:black;">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>