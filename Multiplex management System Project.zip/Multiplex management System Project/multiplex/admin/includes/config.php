<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="multiplex";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>