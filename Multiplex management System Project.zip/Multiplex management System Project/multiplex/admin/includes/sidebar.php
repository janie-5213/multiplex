
<nav class="ts-sidebar" style="background-color:#e7e5e5;">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label" style="color:black;">Main</li>
				<li><a href="dashboard.php" style="color:black;"><i class="fa fa-dashboard"style="color:black;"></i> Dashboard</a></li>

				<li ><a href="registration.php" style="color:black;" style="color:black;"><i class="fa fa-user"></i> Registration</a></li>
				<li ><a href="manage-parking-officers.php" style="color:black;"><i class="fa fa-users"></i>Manage Parking officers</a></li>

				<li><a href="/" style="color:black;"><i class="fa fa-files-o" style="color:black;"></i>Invoice</a>
					<ul>
						<li style="color:black;"><a href="invoice.php"style="color:black;">Add invoice</a></li>
					</ul>
				</li>
					<li><a href="#" style="color:black;"><i class="fa fa-users"></i>Other Staff </a>
				</li>

				</li>
					<li><a href="#" style="color:black;"><i class="fa fa-file"></i>Add Notifications</a>
				</li>

				</li>
					<li><a href="#" style="color:black;"><i class="fa fa-users"></i>Tracking Parking officers </a>
				</li>

				<li><a href="access-log.php"style="color:black;"><i class="fa fa-file"></i>User Access logs</a></li>

			
		</nav>